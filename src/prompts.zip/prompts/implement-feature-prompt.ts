/**
 * Implement feature from spec and tasks
 * Validates spec reference, checks for code reuse, confirms modifications before implementation
 */
export const IMPLEMENT_FEATURE_PROMPT = `# Implement Feature

**FOCUS: Step 7 implementation is the core. Steps 1-6 are quick checks.**

---

## Step 0: Load Project Context & Forbidden Actions - MANDATORY

**Before implementing any feature, you MUST read and understand project rules.**

### Read These Files NOW (if you haven't this session):

1. **\`.project-memory/prompts/base.md\`** - READ COMPLETELY
   - Focus on: Forbidden Actions section
   - Focus on: Scope & Authority Rules
   - Focus on: Business Logic Protection
   - Focus on: UI/UX Protection (if frontend project)

2. **\`.project-memory/conventions.md\`** - READ COMPLETELY
   - Focus on: Forbidden Actions section
   - Focus on: Code Style Enforcement

3. **\`.project-memory/useful-commands.md\`** - Available dev/build/test commands

4. **\`.project-memory/architecture.md\`** - Current system structure and components

### Verification Required - Output This:

\`\`\`
✅ Project Context Loaded:

FORBIDDEN ACTIONS (from base.md & conventions.md):
[List ALL forbidden actions you found - typically 11+ items like:]
- NO large refactors
- NO dependency changes
- NO config changes
- [... list all you found ...]

Business Logic Protection Rules:
[List the business logic protection rules from base.md]

UI/UX Protection Rules (if frontend):
[List the UI/UX protection rules from base.md]

Conventions:
[List 2-3 key code style patterns from conventions.md]

Commands:
[List 2-3 key commands from useful-commands.md]

Architecture:
[List 2-3 key components from architecture.md]
\`\`\`

### CRITICAL Commitment:

**I WILL FAITHFULLY FOLLOW ALL FORBIDDEN ACTIONS listed in base.md and conventions.md throughout this implementation.**

If I need to do any forbidden action:
1. I will STOP immediately
2. I will use AskUserQuestion to explain why and ask permission
3. I will wait for explicit user approval
4. I will only proceed if user says yes

**CRITICAL: If you cannot list ALL the forbidden actions from base.md and conventions.md, you MUST read those files now.**

Implementing without reading and committing to these rules will violate project standards.

Do not proceed to Steps 1-6 until you've verified and outputted the above.

---

## Steps 1-6: Pre-Implementation

### Step 1-2: Get Spec & Validate
- Ask user for: spec file path + task reference
- Read spec file + tasks-active.json
- Quick check: spec clear? tasks have acceptance criteria?
- Output: "✅ Ready - Spec: [file], Tasks: [IDs]"

### Step 3: Check Dependencies
- Review spec: need new packages?
- If yes: STOP and ask user approval via AskUserQuestion (see Forbidden Actions)
- Output: "✅ Using existing stack" OR "❓ Need approval for [package@version]"

### Step 4: Audit for Reusable Code
- Search codebase for similar features/functions
- Identify what can be reused
- Output: "🔍 Reusable code found: [functions at paths]"

### Step 5: Confirm Modifications
- If modifying existing code: ask user via AskUserQuestion
- Get explicit approval before changing anything
- Output: "✅ Modifications approved"

### Step 6: Verify Alignment
- Task acceptance criteria matches spec?
- Output: "✅ Task-spec aligned"

**After Steps 1-6, proceed IMMEDIATELY to Step 7.**

---

## Step 7: IMPLEMENT (Main Focus - Detailed Substeps)

**THIS IS THE MOST IMPORTANT STEP. Follow every substep carefully.**

For EACH task (if multiple tasks, repeat this entire Step 7 for each one):

### 7.1: Pre-Implementation Checks for This Task

a. **Re-read task details:**
   - Read task from tasks-active.json
   - List out ALL acceptance criteria
   - Note dependencies, priority, specReference

b. **Re-read relevant spec section:**
   - Open spec file
   - Find section referenced by task
   - Note: requirements, edge cases, security considerations

c. **Output what you will implement:**
   \`\`\`
   📋 Task [TASK-ID]: [title]

   Acceptance Criteria:
   1. [criterion 1]
   2. [criterion 2]
   ...

   Spec Requirements:
   - [requirement 1]
   - [requirement 2]

   Implementation Plan:
   - [step 1]
   - [step 2]
   \`\`\`

### 7.2: Study Existing Code Patterns (MANDATORY - Don't Skip)

**BEFORE writing any code, study how existing code is written:**

a. **Find 2-3 similar files in the codebase:**
   - Use Glob or Grep to find files similar to what you're implementing
   - Example: implementing a new prompt? Read existing prompt files
   - Example: adding API endpoint? Read existing endpoint files

b. **Read these files completely:**
   - Don't just skim - actually read the code
   - Identify patterns: How are things named? How are they structured?

c. **Document patterns found:**
   \`\`\`
   🔍 Code Patterns Identified:

   Files studied:
   - [file1.ts]
   - [file2.ts]

   Naming conventions:
   - Functions: [camelCase / PascalCase / other]
   - Variables: [camelCase / snake_case / other]
   - Constants: [UPPER_CASE / other]

   Code structure:
   - Exports: [named / default]
   - Imports: [with .js extension / without]
   - Error handling: [try-catch / throw / other]

   Formatting:
   - Indentation: [tabs / 2 spaces / 4 spaces]
   - Quotes: [single / double]
   - Semicolons: [yes / no]

   Patterns:
   - [functional components / classes]
   - [async-await / promises]
   - [specific patterns observed]
   \`\`\`

**CRITICAL: You MUST output the above before writing ANY code.**

### 7.3: Write Code (Match Existing Style Exactly)

Now implement the task:

a. **Before modifying any existing code - Check for protected areas:**

   **Business Logic Check:**
   - Does this file contain calculations, formulas, or algorithms?
   - Does this file contain validation rules or business constraints?
   - Does this file contain data transformations or mappings?
   - **If YES: Do NOT modify without explicit user approval**
   - Ask via AskUserQuestion: "This code contains business logic [describe]. Can I modify it?"

   **UI/UX Check (Frontend Projects):**
   - Does this file contain UI copy/text strings?
   - Does this file define visual styles (colors, layouts, spacing)?
   - Does this file control user flows or navigation?
   - Does this file handle accessibility features (ARIA, keyboard nav)?
   - **If YES: Do NOT modify without explicit user approval**
   - Ask via AskUserQuestion: "This code contains UI/UX [describe]. Can I modify it?"

b. **Create or modify files:**
   - Follow the patterns you documented in 7.2
   - Use SAME naming conventions
   - Use SAME code structure
   - Use SAME formatting
   - Follow conventions.md strictly

c. **As you write, continuously verify:**
   - Does this match existing code style? [yes/no]
   - Am I following conventions.md? [yes/no]
   - Am I introducing new patterns? [no = good, yes = bad]
   - Am I modifying business logic? [no = good, if yes = ask first]
   - Am I modifying UI/UX (copy, design, flows)? [no = good, if yes = ask first]

d. **Handle edge cases from spec:**
   - Review edge cases listed in spec
   - Add error handling for each
   - Add validation where needed

e. **Add security measures:**
   - Follow security rules from base.md
   - No hardcoded secrets
   - Validate inputs at boundaries
   - Proper error messages (no stack traces)

### 7.4: Verify Against Acceptance Criteria (MANDATORY Checkpoint)

**STOP and verify before proceeding:**

\`\`\`
✅ Verification Checklist for [TASK-ID]:

Acceptance Criteria:
□ [criterion 1] - Implemented: [yes/no] - Location: [file:line]
□ [criterion 2] - Implemented: [yes/no] - Location: [file:line]
...

Code Quality:
□ Matches existing code style: [yes/no]
□ Follows conventions.md: [yes/no]
□ No new patterns introduced: [yes/no]
□ No business logic modified without approval: [yes/no]
□ No UI/UX modified without approval (frontend): [yes/no]
□ Edge cases handled: [yes/no]
□ Security measures applied: [yes/no]

Spec Alignment:
□ All spec requirements met: [yes/no]
□ No requirements missed: [yes/no]
\`\`\`

**If ANY checkbox is "no", fix it before proceeding.**

### 7.5: Run Linter and Fix Errors

a. **Run linter:**
   - \`npm run lint\` (or appropriate command from useful-commands.md)
   - Check for any errors or warnings

b. **Fix ALL linting errors:**
   - Address each error/warning
   - Re-run linter until clean

c. **Output:**
   \`\`\`
   ✅ Linting passed:
   - Command: npm run lint
   - Result: [no errors / X errors fixed]
   \`\`\`

### 7.6: Build and Test

a. **Run build:**
   - \`npm run build\` (or from useful-commands.md)
   - Must succeed with no errors

b. **Run tests:**
   - \`npm test\` (or from useful-commands.md)
   - All tests must pass

c. **Output results:**
   \`\`\`
   ✅ Build & Tests:
   - Build: [success/failed]
   - Tests: [X/Y passed]
   - Type errors: [none/list]
   \`\`\`

**If build or tests fail, fix issues and re-verify Step 7.4.**

### 7.7: Final Task Summary

\`\`\`
✅ Task [TASK-ID] Complete:

Files modified/created:
- [file1.ts] - [what changed]
- [file2.ts] - [what changed]

Acceptance criteria:
✅ All met

Code quality:
✅ Matches existing style
✅ Follows conventions.md
✅ Linting passed
✅ Build successful
✅ Tests passed

Ready for: [next task / review / commit]
\`\`\`

---

**If multiple tasks: Repeat Step 7 (7.1 through 7.7) for EACH task.**

---

## Rules (Emphasizing Step 7)

- **Steps 1-6 are quick checks**
- **Step 7 is where you spend 80% of your time** - Follow every substep
- **Study existing code patterns (7.2) is MANDATORY** - Never skip this
- **Verify against acceptance criteria (7.4) is MANDATORY** - Never skip this
- **Match existing code style exactly** - No new patterns unless requested
- **Run linters and fix errors** - Must pass before considering task done
- **Build and tests must pass** - Non-negotiable
- **One task at a time** - Complete Step 7 fully before moving to next task

---

## Checklist Before Starting Step 7

- ✅ Loaded project context (Step 0)
- ✅ Got spec and task reference (Step 1-2)
- ✅ Checked dependencies (Step 3)
- ✅ Identified reusable code (Step 4)
- ✅ Got user approval for modifications (Step 5)
- ✅ Verified task-spec alignment (Step 6)
- ✅ Ready to implement (Step 7)

Done!
`.trim()
